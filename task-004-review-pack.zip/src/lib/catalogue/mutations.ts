import "server-only";

import { randomUUID } from "node:crypto";

import type { Prisma } from "@/generated/prisma/client";
import {
  CatalogueConflictError,
  CataloguePublicationError,
  CatalogueTransitionError,
  pendingChangesConflictMessage,
} from "@/lib/catalogue/errors";
import {
  createOwnedMediaReference,
  mediaOwnerWhere,
} from "@/lib/catalogue/media";
import { publicationIssues } from "@/lib/catalogue/rules";
import { wouldCreateRecommendationCycle } from "@/lib/catalogue/recommendations";
import {
  editableSnapshot,
  loadServiceAggregate,
  mutatePublishedStage,
  persistServiceStage,
} from "@/lib/catalogue/staging-repository";
import {
  addStagedMedia,
  addStagedRequirement,
  applyServiceEdit,
  assertArchiveTransition,
  primaryMedia,
  publicationEventFromHistory,
  removeStagedMedia,
  removeStagedRequirement,
  removeStagedOffering,
  snapshotFromService,
  upsertStagedOffering,
  type StagedCatalogueAggregate,
} from "@/lib/catalogue/staging";
import {
  categoryInputSchema,
  mediaReferenceInputSchema,
  nextDuplicateSlug,
  offeringInputSchema,
  offeringRequirementInputSchema,
  requirementInputSchema,
  serviceInputSchema,
} from "@/lib/catalogue/validation";
import { prisma } from "@/lib/db/prisma";

type CategoryInput = ReturnType<typeof categoryInputSchema.parse>;
type ServiceInput = ReturnType<typeof serviceInputSchema.parse>;
type RequirementInput = ReturnType<typeof requirementInputSchema.parse>;
type MediaInput = ReturnType<typeof mediaReferenceInputSchema.parse>;
type OfferingInput = ReturnType<typeof offeringInputSchema.parse>;
type OfferingRequirementInput = ReturnType<
  typeof offeringRequirementInputSchema.parse
>;

function auditMetadata(value: Record<string, unknown>) {
  return JSON.parse(JSON.stringify(value)) as Prisma.InputJsonValue;
}

function revisionSnapshot(value: unknown) {
  return JSON.parse(JSON.stringify(value)) as Prisma.InputJsonValue;
}

export async function createCategory(input: CategoryInput, actorId: string) {
  return prisma.$transaction(async (transaction) => {
    const category = await transaction.catalogueCategory.create({
      data: input,
    });
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.category.created",
        targetType: "CatalogueCategory",
        targetId: category.id,
        metadata: auditMetadata({ slug: category.slug }),
      },
    });
    return category;
  });
}

export async function updateCategory(
  id: string,
  input: CategoryInput,
  actorId: string,
) {
  return prisma.$transaction(async (transaction) => {
    const previous = await transaction.catalogueCategory.findUniqueOrThrow({
      where: { id },
    });
    const category = await transaction.catalogueCategory.update({
      where: { id },
      data: input,
    });
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.category.updated",
        targetType: "CatalogueCategory",
        targetId: id,
        metadata: auditMetadata({
          slug: category.slug,
          activeChanged: previous.isActive !== category.isActive,
          orderChanged: previous.displayOrder !== category.displayOrder,
          seoChanged:
            previous.seoTitle !== category.seoTitle ||
            previous.seoDescription !== category.seoDescription,
        }),
      },
    });
    return category;
  });
}

export async function createService(input: ServiceInput, actorId: string) {
  const { gameModes, version: _version, ...data } = input;
  void _version;
  return prisma.$transaction(async (transaction) => {
    await transaction.catalogueCategory.findUniqueOrThrow({
      where: { id: data.categoryId },
    });
    const service = await transaction.catalogueService.create({
      data: {
        ...data,
        publicationStatus: "DRAFT",
        createdById: actorId,
        updatedById: actorId,
        gameModes: {
          create: gameModes.map((gameMode) => ({ gameMode })),
        },
      },
    });
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.service.created",
        targetType: "CatalogueService",
        targetId: service.id,
        metadata: auditMetadata({
          categoryId: service.categoryId,
          slug: service.slug,
          engineType: service.engineType,
        }),
      },
    });
    return service;
  });
}

export async function updateService(
  id: string,
  input: ServiceInput,
  actorId: string,
) {
  const { gameModes, version, ...data } = input;
  return prisma.$transaction(async (transaction) => {
    const previous = await loadServiceAggregate(transaction, id);
    if (previous.publicationStatus === "PUBLISHED") {
      const snapshot = applyServiceEdit(editableSnapshot(previous), {
        ...data,
        gameModes,
      });
      const stage = await persistServiceStage({
        transaction,
        service: previous,
        snapshot,
        actorId,
        expectedVersion: version,
      });
      await transaction.auditLog.create({
        data: {
          actorId,
          action: "catalogue.service.changes_staged",
          targetType: "CatalogueService",
          targetId: id,
          metadata: auditMetadata({
            stageVersion: stage.version,
            availabilityChanged:
              previous.availabilityState !== data.availabilityState,
            seoChanged:
              previous.seoTitle !== data.seoTitle ||
              previous.seoDescription !== data.seoDescription,
            gameModesChanged: true,
          }),
        },
      });
      return { id, staged: true };
    }

    const result = await transaction.catalogueService.updateMany({
      where: { id, version },
      data: {
        ...data,
        updatedById: actorId,
        version: { increment: 1 },
      },
    });
    if (result.count !== 1) {
      throw new CatalogueConflictError(
        "This service changed after the editor was opened. Reload before saving.",
      );
    }
    await transaction.catalogueServiceGameMode.deleteMany({
      where: { serviceId: id },
    });
    await transaction.catalogueServiceGameMode.createMany({
      data: gameModes.map((gameMode) => ({ serviceId: id, gameMode })),
    });
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.service.updated",
        targetType: "CatalogueService",
        targetId: id,
        metadata: auditMetadata({
          status: previous.publicationStatus,
          availabilityChanged:
            previous.availabilityState !== data.availabilityState,
          seoChanged:
            previous.seoTitle !== data.seoTitle ||
            previous.seoDescription !== data.seoDescription,
          gameModesChanged: true,
        }),
      },
    });
    if (previous.availabilityState !== data.availabilityState) {
      await transaction.auditLog.create({
        data: {
          actorId,
          action: "catalogue.service.availability_changed",
          targetType: "CatalogueService",
          targetId: id,
          metadata: auditMetadata({
            from: previous.availabilityState,
            to: data.availabilityState,
          }),
        },
      });
    }
    if (
      previous.seoTitle !== data.seoTitle ||
      previous.seoDescription !== data.seoDescription
    ) {
      await transaction.auditLog.create({
        data: {
          actorId,
          action: "catalogue.service.seo_changed",
          targetType: "CatalogueService",
          targetId: id,
          metadata: auditMetadata({ hasTitle: Boolean(data.seoTitle) }),
        },
      });
    }
    return { id, staged: false };
  });
}

function serviceDataFromSnapshot(snapshot: StagedCatalogueAggregate) {
  const service = snapshot.service;
  return {
    categoryId: service.categoryId,
    name: service.name,
    slug: service.slug,
    canonicalSlug: service.canonicalSlug,
    shortSummary: service.shortSummary,
    content: service.content,
    serviceType: service.serviceType,
    engineType: service.engineType,
    availabilityState: service.availabilityState,
    isFeatured: service.isFeatured,
    isQuoteOnly: service.isQuoteOnly,
    displayOrder: service.displayOrder,
    internalNotes: service.internalNotes,
    publicPreparationNotes: service.publicPreparationNotes,
    primaryMediaPath: primaryMedia(snapshot)?.assetPath ?? null,
    seoTitle: service.seoTitle,
    seoDescription: service.seoDescription,
    publishAt: service.publishAt ? new Date(service.publishAt) : null,
    unpublishAt: service.unpublishAt ? new Date(service.unpublishAt) : null,
    needsClientReview: service.needsClientReview,
  };
}

export async function publishService(
  id: string,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await loadServiceAggregate(transaction, id);
    if (service.publicationStatus === "PUBLISHED" && !service.stage) {
      throw new CatalogueTransitionError(
        "There are no pending changes to republish.",
      );
    }
    if (service.stage && service.stage.baseVersion !== service.version) {
      throw new CatalogueConflictError(
        "The published version changed after these edits were staged. Discard or review the pending changes.",
      );
    }

    let claimedStageVersion: number | null = null;
    let claimedServiceVersion: number;
    if (service.stage) {
      const claim = await transaction.catalogueServiceStage.updateMany({
        where: {
          id: service.stage.id,
          serviceId: id,
          version: expectedVersion,
        },
        data: {
          updatedById: actorId,
          version: { increment: 1 },
        },
      });
      if (claim.count !== 1) {
        throw new CatalogueConflictError(pendingChangesConflictMessage);
      }
      claimedStageVersion = expectedVersion + 1;
      claimedServiceVersion = claimedStageVersion;
    } else {
      const claim = await transaction.catalogueService.updateMany({
        where: { id, version: expectedVersion },
        data: { updatedById: actorId, version: { increment: 1 } },
      });
      if (claim.count !== 1) {
        throw new CatalogueConflictError(
          "This service changed after the editor was opened. Reload before continuing.",
        );
      }
      claimedServiceVersion = expectedVersion + 1;
    }

    const snapshot = service.stage
      ? editableSnapshot(service)
      : snapshotFromService(service);
    const category = await transaction.catalogueCategory.findUniqueOrThrow({
      where: { id: snapshot.service.categoryId },
    });
    const candidate = {
      ...snapshot.service,
      publishAt: snapshot.service.publishAt
        ? new Date(snapshot.service.publishAt)
        : null,
      unpublishAt: snapshot.service.unpublishAt
        ? new Date(snapshot.service.unpublishAt)
        : null,
      category,
      gameModes: snapshot.gameModes,
    };
    const issues = publicationIssues(candidate);
    if (issues.length) throw new CataloguePublicationError(issues);

    const revisions = await transaction.catalogueRevision.findMany({
      where: { serviceId: id },
      select: { event: true, revisionNumber: true },
      orderBy: { revisionNumber: "desc" },
    });
    const event = publicationEventFromHistory(
      revisions.map(({ event: revisionEvent }) => revisionEvent),
    );
    const previousRoute = {
      categorySlug: service.category.slug,
      serviceSlug: service.slug,
    };

    const serviceUpdate = await transaction.catalogueService.updateMany({
      where: {
        id,
        version: service.stage ? service.version : claimedServiceVersion,
      },
      data: {
        ...serviceDataFromSnapshot(snapshot),
        publicationStatus: "PUBLISHED",
        updatedById: actorId,
        ...(service.stage ? { version: claimedServiceVersion } : {}),
      },
    });
    if (serviceUpdate.count !== 1) {
      throw new CatalogueConflictError(
        service.stage
          ? pendingChangesConflictMessage
          : "This service changed after the editor was opened. Reload before continuing.",
      );
    }
    await transaction.catalogueServiceGameMode.deleteMany({
      where: { serviceId: id },
    });
    await transaction.catalogueServiceGameMode.createMany({
      data: snapshot.gameModes.map((gameMode) => ({ serviceId: id, gameMode })),
    });
    await transaction.catalogueRequirement.deleteMany({
      where: { serviceId: id },
    });
    if (snapshot.requirements.length) {
      await transaction.catalogueRequirement.createMany({
        data: snapshot.requirements.map((requirement) => ({
          ...requirement,
          serviceId: id,
        })),
      });
    }
    await transaction.catalogueOffering.deleteMany({
      where: { serviceId: id },
    });
    for (const offering of snapshot.offerings) {
      await transaction.catalogueOffering.create({
        data: {
          id: offering.id,
          serviceId: id,
          seededKey: offering.seededKey,
          slug: offering.slug,
          name: offering.name,
          shortSummary: offering.shortSummary,
          description: offering.description,
          displayOrder: offering.displayOrder,
          isActive: offering.isActive,
          isFeatured: offering.isFeatured,
          needsClientReview: offering.needsClientReview,
          groupLabel: offering.groupLabel,
          tierLabel: offering.tierLabel,
          quantityEnabled: offering.quantityEnabled,
          quantityUnit: offering.quantityEnabled ? offering.quantityUnit : null,
          minimumQuantity: offering.quantityEnabled
            ? offering.minimumQuantity
            : null,
          maximumQuantity: offering.quantityEnabled
            ? offering.maximumQuantity
            : null,
          gameModes: {
            create: offering.gameModes.map((gameMode) => ({ gameMode })),
          },
          facets: {
            create: offering.facets.map(({ id: facetId, ...facet }) => ({
              id: facetId,
              ...facet,
            })),
          },
          requirements: {
            create: offering.requirements.map(
              ({ id: requirementId, ...requirement }) => ({
                id: requirementId,
                ...requirement,
              }),
            ),
          },
        },
      });
    }
    await transaction.catalogueMediaReference.deleteMany({
      where: { serviceId: id },
    });
    if (snapshot.mediaReferences.length) {
      await transaction.catalogueMediaReference.createMany({
        data: snapshot.mediaReferences.map((media) => ({
          ...media,
          serviceId: id,
        })),
      });
    }

    const published = await transaction.catalogueService.findUniqueOrThrow({
      where: { id },
      include: {
        category: true,
        gameModes: { orderBy: { gameMode: "asc" } },
        requirements: { orderBy: { displayOrder: "asc" } },
        mediaReferences: {
          orderBy: [{ isPrimary: "desc" }, { displayOrder: "asc" }],
        },
        offerings: {
          orderBy: [{ displayOrder: "asc" }, { name: "asc" }],
          include: { gameModes: true, facets: true, requirements: true },
        },
      },
    });
    await transaction.catalogueRevision.create({
      data: {
        serviceId: id,
        revisionNumber: (revisions[0]?.revisionNumber ?? 0) + 1,
        event,
        publicationStatus: "PUBLISHED",
        summary:
          event === "PUBLISHED"
            ? "Service published for the first time."
            : "Published service content updated.",
        snapshot: revisionSnapshot(published),
        actorId,
      },
    });
    await transaction.auditLog.create({
      data: {
        actorId,
        action:
          event === "PUBLISHED"
            ? "catalogue.service.published"
            : "catalogue.service.republished",
        targetType: "CatalogueService",
        targetId: id,
        metadata: auditMetadata({
          slug: published.slug,
          categoryId: published.categoryId,
          staged: Boolean(service.stage),
        }),
      },
    });
    if (event === "REPUBLISHED" && snapshot.offerings.length > 0) {
      await transaction.auditLog.create({
        data: {
          actorId,
          action: "catalogue.offering.aggregate_republished",
          targetType: "CatalogueService",
          targetId: id,
          metadata: auditMetadata({ offeringCount: snapshot.offerings.length }),
        },
      });
    }
    if (service.stage) {
      const deleted = await transaction.catalogueServiceStage.deleteMany({
        where: {
          id: service.stage.id,
          serviceId: id,
          version: claimedStageVersion!,
        },
      });
      if (deleted.count !== 1) {
        throw new CatalogueConflictError(pendingChangesConflictMessage);
      }
    }
    return {
      published,
      event,
      previousRoute,
      currentRoute: {
        categorySlug: published.category.slug,
        serviceSlug: published.slug,
      },
    };
  });
}

export async function archiveService(
  id: string,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await loadServiceAggregate(transaction, id);
    assertArchiveTransition(service.publicationStatus, Boolean(service.stage));
    const aggregate = await transaction.catalogueRevision.aggregate({
      where: { serviceId: id },
      _max: { revisionNumber: true },
    });
    const claim = await transaction.catalogueService.updateMany({
      where: { id, version: expectedVersion, publicationStatus: "PUBLISHED" },
      data: {
        publicationStatus: "ARCHIVED",
        updatedById: actorId,
        version: { increment: 1 },
      },
    });
    if (claim.count !== 1) {
      throw new CatalogueConflictError(
        "This service changed after the editor was opened. Reload before continuing.",
      );
    }
    const archived = await transaction.catalogueService.findUniqueOrThrow({
      where: { id },
      include: {
        category: true,
        gameModes: true,
        requirements: true,
        mediaReferences: true,
      },
    });
    await transaction.catalogueRevision.create({
      data: {
        serviceId: id,
        revisionNumber: (aggregate._max.revisionNumber ?? 0) + 1,
        event: "ARCHIVED",
        publicationStatus: "ARCHIVED",
        summary: "Service archived and removed from public discovery.",
        snapshot: revisionSnapshot(archived),
        actorId,
      },
    });
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.service.archived",
        targetType: "CatalogueService",
        targetId: id,
        metadata: auditMetadata({ previousStatus: service.publicationStatus }),
      },
    });
    return {
      archived,
      previousRoute: {
        categorySlug: service.category.slug,
        serviceSlug: service.slug,
      },
    };
  });
}

export async function discardServiceStage(
  id: string,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await transaction.catalogueService.findUniqueOrThrow({
      where: { id },
      include: { stage: true },
    });
    if (!service.stage) {
      throw new CatalogueTransitionError(
        "There are no pending changes to discard.",
      );
    }
    const deleted = await transaction.catalogueServiceStage.deleteMany({
      where: {
        id: service.stage.id,
        serviceId: id,
        version: expectedVersion,
      },
    });
    if (deleted.count !== 1) {
      throw new CatalogueConflictError(pendingChangesConflictMessage);
    }
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.service.changes_discarded",
        targetType: "CatalogueService",
        targetId: id,
        metadata: auditMetadata({ stageVersion: expectedVersion }),
      },
    });
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.offering.changes_discarded",
        targetType: "CatalogueService",
        targetId: id,
        metadata: auditMetadata({ stageVersion: expectedVersion }),
      },
    });
    return service;
  });
}

export async function duplicateService(id: string, actorId: string) {
  return prisma.$transaction(async (transaction) => {
    const source = await transaction.catalogueService.findUniqueOrThrow({
      where: { id },
      include: {
        gameModes: true,
        requirements: true,
        mediaReferences: true,
        offerings: {
          include: { gameModes: true, facets: true, requirements: true },
        },
      },
    });
    const existing = await transaction.catalogueService.findMany({
      select: { slug: true, canonicalSlug: true },
    });
    const slug = nextDuplicateSlug(
      source.slug,
      existing.map((item) => item.slug),
    );
    const canonicalSlug = nextDuplicateSlug(
      source.canonicalSlug,
      existing.map((item) => item.canonicalSlug),
    );
    const duplicate = await transaction.catalogueService.create({
      data: {
        categoryId: source.categoryId,
        name: `${source.name} copy`,
        slug,
        canonicalSlug,
        shortSummary: source.shortSummary,
        content: source.content,
        serviceType: source.serviceType,
        engineType: source.engineType,
        publicationStatus: "DRAFT",
        availabilityState: source.availabilityState,
        isFeatured: false,
        isQuoteOnly: source.isQuoteOnly,
        displayOrder: source.displayOrder,
        internalNotes: source.internalNotes,
        publicPreparationNotes: source.publicPreparationNotes,
        primaryMediaPath:
          source.mediaReferences.find((media) => media.isPrimary)?.assetPath ??
          null,
        seoTitle: source.seoTitle,
        seoDescription: source.seoDescription,
        createdById: actorId,
        updatedById: actorId,
        needsClientReview: true,
        gameModes: {
          create: source.gameModes.map(({ gameMode }) => ({ gameMode })),
        },
        requirements: {
          create: source.requirements.map((requirement) => ({
            title: requirement.title,
            description: requirement.description,
            type: requirement.type,
            isRequired: requirement.isRequired,
            displayOrder: requirement.displayOrder,
            verificationMode: requirement.verificationMode,
            customerGuidance: requirement.customerGuidance,
            metricKey: requirement.metricKey,
            comparisonOperator: requirement.comparisonOperator,
            requiredValue: requirement.requiredValue,
            recommendedServiceId: requirement.recommendedServiceId,
          })),
        },
        mediaReferences: {
          create: source.mediaReferences.map((media) => ({
            assetPath: media.assetPath,
            altText: media.altText,
            caption: media.caption,
            displayOrder: media.displayOrder,
            isPrimary: media.isPrimary,
          })),
        },
        offerings: {
          create: source.offerings.map((offering) => ({
            slug: offering.slug,
            name: offering.name,
            shortSummary: offering.shortSummary,
            description: offering.description,
            displayOrder: offering.displayOrder,
            isActive: offering.isActive,
            isFeatured: false,
            needsClientReview: true,
            groupLabel: offering.groupLabel,
            tierLabel: offering.tierLabel,
            quantityEnabled: offering.quantityEnabled,
            quantityUnit: offering.quantityUnit,
            minimumQuantity: offering.minimumQuantity,
            maximumQuantity: offering.maximumQuantity,
            gameModes: {
              create: offering.gameModes.map(({ gameMode }) => ({ gameMode })),
            },
            facets: {
              create: offering.facets.map((facet) => ({
                facetKey: facet.facetKey,
                facetValue: facet.facetValue,
                label: facet.label,
                displayOrder: facet.displayOrder,
              })),
            },
            requirements: {
              create: offering.requirements.map((requirement) => ({
                title: requirement.title,
                description: requirement.description,
                type: requirement.type,
                isRequired: requirement.isRequired,
                displayOrder: requirement.displayOrder,
                verificationMode: requirement.verificationMode,
                customerGuidance: requirement.customerGuidance,
                metricKey: requirement.metricKey,
                comparisonOperator: requirement.comparisonOperator,
                requiredValue: requirement.requiredValue,
                recommendedServiceId: requirement.recommendedServiceId,
              })),
            },
          })),
        },
      },
    });
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.service.duplicated",
        targetType: "CatalogueService",
        targetId: duplicate.id,
        metadata: auditMetadata({ sourceId: id, slug }),
      },
    });
    return duplicate;
  });
}

function stagedId() {
  return `stg${randomUUID().replaceAll("-", "").slice(0, 27)}`;
}

async function assertRecommendationIsAcyclic(
  transaction: Prisma.TransactionClient,
  ownerServiceId: string,
  recommendedServiceId: string | null | undefined,
  staged?: StagedCatalogueAggregate,
) {
  if (!recommendedServiceId) return;
  const [serviceRequirements, offeringRequirements] = await Promise.all([
    transaction.catalogueRequirement.findMany({
      where: { recommendedServiceId: { not: null } },
      select: { serviceId: true, recommendedServiceId: true },
    }),
    transaction.catalogueOfferingRequirement.findMany({
      where: { recommendedServiceId: { not: null } },
      select: {
        recommendedServiceId: true,
        offering: { select: { serviceId: true } },
      },
    }),
  ]);
  const edges = new Map<string, string[]>();
  const add = (from: string, to: string | null) => {
    if (to) edges.set(from, [...(edges.get(from) ?? []), to]);
  };
  serviceRequirements.forEach((item) =>
    add(item.serviceId, item.recommendedServiceId),
  );
  offeringRequirements.forEach((item) =>
    add(item.offering.serviceId, item.recommendedServiceId),
  );
  staged?.requirements.forEach((item) =>
    add(ownerServiceId, item.recommendedServiceId),
  );
  staged?.offerings.forEach((offering) =>
    offering.requirements.forEach((item) =>
      add(ownerServiceId, item.recommendedServiceId),
    ),
  );
  if (
    wouldCreateRecommendationCycle(edges, ownerServiceId, recommendedServiceId)
  ) {
    throw new CatalogueTransitionError(
      "This prerequisite recommendation would create a circular chain.",
    );
  }
}

export async function addRequirement(
  input: RequirementInput,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await loadServiceAggregate(transaction, input.serviceId);
    await assertRecommendationIsAcyclic(
      transaction,
      input.serviceId,
      input.recommendedServiceId,
      editableSnapshot(service),
    );
    const stagedRequirement = {
      id: stagedId(),
      title: input.title,
      description: input.description,
      type: input.type,
      isRequired: input.isRequired,
      displayOrder: input.displayOrder,
      verificationMode: input.verificationMode,
      customerGuidance: input.customerGuidance ?? null,
      metricKey: input.metricKey ?? null,
      comparisonOperator: input.comparisonOperator ?? null,
      requiredValue: input.requiredValue ?? null,
      recommendedServiceId: input.recommendedServiceId ?? null,
      seededKey: null,
    };
    const staged = await mutatePublishedStage(
      transaction,
      input.serviceId,
      actorId,
      expectedVersion,
      (snapshot) => addStagedRequirement(snapshot, stagedRequirement),
    );
    if (staged) {
      await transaction.auditLog.create({
        data: {
          actorId,
          action: "catalogue.requirement.change_staged",
          targetType: "CatalogueService",
          targetId: input.serviceId,
          metadata: auditMetadata({ requirementId: stagedRequirement.id }),
        },
      });
      return { ...stagedRequirement, staged: true };
    }

    const requirement = await transaction.catalogueRequirement.create({
      data: input,
    });
    const serviceUpdate = await transaction.catalogueService.updateMany({
      where: { id: input.serviceId, version: expectedVersion },
      data: { updatedById: actorId, version: { increment: 1 } },
    });
    if (serviceUpdate.count !== 1) {
      throw new CatalogueConflictError(
        "This service changed after the editor was opened. Reload before continuing.",
      );
    }
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.requirement.created",
        targetType: "CatalogueService",
        targetId: input.serviceId,
        metadata: auditMetadata({ requirementId: requirement.id }),
      },
    });
    return { ...requirement, staged: false };
  });
}

export async function deleteRequirement(
  serviceId: string,
  requirementId: string,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const staged = await mutatePublishedStage(
      transaction,
      serviceId,
      actorId,
      expectedVersion,
      (snapshot) => {
        if (
          !snapshot.requirements.some(
            (requirement) => requirement.id === requirementId,
          )
        ) {
          throw new CatalogueConflictError("Requirement not found.");
        }
        return removeStagedRequirement(snapshot, requirementId);
      },
    );
    if (staged) {
      await transaction.auditLog.create({
        data: {
          actorId,
          action: "catalogue.requirement.change_staged",
          targetType: "CatalogueService",
          targetId: serviceId,
          metadata: auditMetadata({ requirementId, removed: true }),
        },
      });
      return { staged: true };
    }

    const result = await transaction.catalogueRequirement.deleteMany({
      where: { id: requirementId, serviceId },
    });
    if (result.count !== 1)
      throw new CatalogueConflictError("Requirement not found.");
    const serviceUpdate = await transaction.catalogueService.updateMany({
      where: { id: serviceId, version: expectedVersion },
      data: { updatedById: actorId, version: { increment: 1 } },
    });
    if (serviceUpdate.count !== 1) {
      throw new CatalogueConflictError(
        "This service changed after the editor was opened. Reload before continuing.",
      );
    }
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.requirement.deleted",
        targetType: "CatalogueService",
        targetId: serviceId,
        metadata: auditMetadata({ requirementId }),
      },
    });
    return { staged: false };
  });
}

export async function addMediaReference(
  input: MediaInput,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const owner = mediaOwnerWhere(input);
    if (input.serviceId) {
      const stagedMedia = {
        id: stagedId(),
        assetPath: input.assetPath,
        altText: input.altText,
        caption: input.caption ?? null,
        displayOrder: input.displayOrder,
        isPrimary: input.isPrimary,
      };
      const staged = await mutatePublishedStage(
        transaction,
        input.serviceId,
        actorId,
        expectedVersion,
        (snapshot) => addStagedMedia(snapshot, stagedMedia),
      );
      if (staged) {
        await transaction.auditLog.create({
          data: {
            actorId,
            action: "catalogue.media.change_staged",
            targetType: "CatalogueService",
            targetId: input.serviceId,
            metadata: auditMetadata({
              mediaId: stagedMedia.id,
              isPrimary: stagedMedia.isPrimary,
            }),
          },
        });
        return { ...stagedMedia, staged: true };
      }
    }

    const media = await createOwnedMediaReference(input, {
      clearPrimary: async (where) => {
        await transaction.catalogueMediaReference.updateMany({
          where,
          data: { isPrimary: false },
        });
      },
      create: (data) => transaction.catalogueMediaReference.create({ data }),
    });
    if (input.serviceId) {
      const serviceUpdate = await transaction.catalogueService.updateMany({
        where: { id: input.serviceId, version: expectedVersion },
        data: {
          ...(input.isPrimary ? { primaryMediaPath: input.assetPath } : {}),
          updatedById: actorId,
          version: { increment: 1 },
        },
      });
      if (serviceUpdate.count !== 1) {
        throw new CatalogueConflictError(
          "This service changed after the editor was opened. Reload before continuing.",
        );
      }
    } else if (input.categoryId && input.isPrimary) {
      await transaction.catalogueCategory.update({
        where: { id: input.categoryId },
        data: { imagePath: input.assetPath },
      });
    }
    const targetType = input.serviceId
      ? "CatalogueService"
      : "CatalogueCategory";
    const targetId = input.serviceId ?? input.categoryId!;
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.media.created",
        targetType,
        targetId,
        metadata: auditMetadata({
          mediaId: media.id,
          isPrimary: input.isPrimary,
          owner,
        }),
      },
    });
    return { ...media, staged: false };
  });
}

export async function deleteMediaReference(
  serviceId: string,
  mediaId: string,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const staged = await mutatePublishedStage(
      transaction,
      serviceId,
      actorId,
      expectedVersion,
      (snapshot) => {
        if (!snapshot.mediaReferences.some((media) => media.id === mediaId)) {
          throw new CatalogueConflictError("Media reference not found.");
        }
        return removeStagedMedia(snapshot, mediaId);
      },
    );
    if (staged) {
      await transaction.auditLog.create({
        data: {
          actorId,
          action: "catalogue.media.change_staged",
          targetType: "CatalogueService",
          targetId: serviceId,
          metadata: auditMetadata({ mediaId, removed: true }),
        },
      });
      return { staged: true };
    }

    const media = await transaction.catalogueMediaReference.findFirst({
      where: { id: mediaId, serviceId },
    });
    if (!media) throw new CatalogueConflictError("Media reference not found.");
    await transaction.catalogueMediaReference.delete({
      where: { id: mediaId },
    });
    const serviceUpdate = await transaction.catalogueService.updateMany({
      where: { id: serviceId, version: expectedVersion },
      data: {
        ...(media.isPrimary ? { primaryMediaPath: null } : {}),
        updatedById: actorId,
        version: { increment: 1 },
      },
    });
    if (serviceUpdate.count !== 1) {
      throw new CatalogueConflictError(
        "This service changed after the editor was opened. Reload before continuing.",
      );
    }
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.media.deleted",
        targetType: "CatalogueService",
        targetId: serviceId,
        metadata: auditMetadata({ mediaId }),
      },
    });
    return { staged: false };
  });
}

function offeringFromInput(
  input: OfferingInput,
  id: string,
  existing?: StagedCatalogueAggregate["offerings"][number],
): StagedCatalogueAggregate["offerings"][number] {
  return {
    id,
    seededKey: existing?.seededKey ?? null,
    slug: input.slug,
    name: input.name,
    shortSummary: input.shortSummary,
    description: input.description ?? null,
    displayOrder: input.displayOrder,
    isActive: input.isActive,
    isFeatured: input.isFeatured,
    needsClientReview: input.needsClientReview,
    groupLabel: input.groupLabel ?? null,
    tierLabel: input.tierLabel ?? null,
    quantityEnabled: input.quantityEnabled,
    quantityUnit: input.quantityEnabled ? (input.quantityUnit ?? null) : null,
    minimumQuantity: input.quantityEnabled
      ? (input.minimumQuantity ?? null)
      : null,
    maximumQuantity: input.quantityEnabled
      ? (input.maximumQuantity ?? null)
      : null,
    gameModes: input.gameModes,
    facets: input.facets.map((facet) => ({
      id:
        existing?.facets.find(
          (item) =>
            item.facetKey === facet.facetKey &&
            item.facetValue === facet.facetValue,
        )?.id ?? stagedId(),
      ...facet,
    })),
    requirements: existing?.requirements ?? [],
  };
}

function offeringUpdateAction(
  previous: StagedCatalogueAggregate["offerings"][number] | undefined,
  current: StagedCatalogueAggregate["offerings"][number],
  staged: boolean,
) {
  if (!previous) {
    return staged
      ? "catalogue.offering.created_staged"
      : "catalogue.offering.created";
  }
  if (previous.isActive !== current.isActive) {
    return current.isActive
      ? "catalogue.offering.activated"
      : "catalogue.offering.deactivated";
  }
  if (previous.displayOrder !== current.displayOrder) {
    return "catalogue.offering.reordered";
  }
  if (JSON.stringify(previous.facets) !== JSON.stringify(current.facets)) {
    return "catalogue.offering.facets_changed";
  }
  if (
    JSON.stringify(previous.gameModes) !== JSON.stringify(current.gameModes)
  ) {
    return "catalogue.offering.game_modes_changed";
  }
  return staged
    ? "catalogue.offering.updated_staged"
    : "catalogue.offering.updated";
}

async function claimDraftService(
  transaction: Prisma.TransactionClient,
  serviceId: string,
  actorId: string,
  expectedVersion: number,
) {
  const claimed = await transaction.catalogueService.updateMany({
    where: {
      id: serviceId,
      version: expectedVersion,
      publicationStatus: { not: "PUBLISHED" },
    },
    data: { updatedById: actorId, version: { increment: 1 } },
  });
  if (claimed.count !== 1) {
    throw new CatalogueConflictError(
      "This service changed after the editor was opened. Reload before continuing.",
    );
  }
}

export async function saveOffering(
  input: OfferingInput,
  actorId: string,
  expectedVersion: number,
  offeringId?: string,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await loadServiceAggregate(transaction, input.serviceId);
    if (
      input.gameModes.some(
        (mode) => !service.gameModes.some((item) => item.gameMode === mode),
      )
    ) {
      throw new CatalogueTransitionError(
        "Offering game modes must be supported by the parent service.",
      );
    }
    const id = offeringId ?? stagedId();
    if (service.publicationStatus === "PUBLISHED") {
      const editable = editableSnapshot(service);
      const existing = editable.offerings.find(
        (offering) => offering.id === id,
      );
      if (offeringId && !existing)
        throw new CatalogueConflictError("Offering not found.");
      const offering = offeringFromInput(input, id, existing);
      const result = await persistServiceStage({
        transaction,
        service,
        snapshot: upsertStagedOffering(editable, offering),
        actorId,
        expectedVersion,
      });
      await transaction.auditLog.create({
        data: {
          actorId,
          action: offeringUpdateAction(existing, offering, true),
          targetType: "CatalogueOffering",
          targetId: id,
          metadata: auditMetadata({
            serviceId: input.serviceId,
            stageVersion: result.version,
          }),
        },
      });
      return { id, staged: true };
    }

    await claimDraftService(
      transaction,
      input.serviceId,
      actorId,
      expectedVersion,
    );
    const data = {
      slug: input.slug,
      name: input.name,
      shortSummary: input.shortSummary,
      description: input.description,
      displayOrder: input.displayOrder,
      isActive: input.isActive,
      isFeatured: input.isFeatured,
      needsClientReview: input.needsClientReview,
      groupLabel: input.groupLabel,
      tierLabel: input.tierLabel,
      quantityEnabled: input.quantityEnabled,
      quantityUnit: input.quantityEnabled ? input.quantityUnit : null,
      minimumQuantity: input.quantityEnabled ? input.minimumQuantity : null,
      maximumQuantity: input.quantityEnabled ? input.maximumQuantity : null,
    };
    const previousOffering = snapshotFromService(service).offerings.find(
      (item) => item.id === offeringId,
    );
    const offering = offeringId
      ? await transaction.catalogueOffering.update({
          where: { id: offeringId, serviceId: input.serviceId },
          data: {
            ...data,
            facets: { deleteMany: {}, create: input.facets },
            gameModes: {
              deleteMany: {},
              create: input.gameModes.map((gameMode) => ({ gameMode })),
            },
          },
        })
      : await transaction.catalogueOffering.create({
          data: {
            id,
            serviceId: input.serviceId,
            ...data,
            facets: { create: input.facets },
            gameModes: {
              create: input.gameModes.map((gameMode) => ({ gameMode })),
            },
          },
        });
    await transaction.auditLog.create({
      data: {
        actorId,
        action: offeringUpdateAction(
          previousOffering,
          offeringFromInput(input, offering.id, previousOffering),
          false,
        ),
        targetType: "CatalogueOffering",
        targetId: offering.id,
        metadata: auditMetadata({ serviceId: input.serviceId }),
      },
    });
    return { id: offering.id, staged: false };
  });
}

export async function deleteOffering(
  serviceId: string,
  offeringId: string,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await loadServiceAggregate(transaction, serviceId);
    if (service.publicationStatus === "PUBLISHED") {
      const snapshot = editableSnapshot(service);
      if (!snapshot.offerings.some(({ id }) => id === offeringId)) {
        throw new CatalogueConflictError("Offering not found.");
      }
      const persisted = await persistServiceStage({
        transaction,
        service,
        snapshot: removeStagedOffering(snapshot, offeringId),
        actorId,
        expectedVersion,
      });
      await transaction.auditLog.create({
        data: {
          actorId,
          action: "catalogue.offering.deleted_staged",
          targetType: "CatalogueOffering",
          targetId: offeringId,
          metadata: auditMetadata({
            serviceId,
            stageVersion: persisted.version,
          }),
        },
      });
      return { staged: true };
    }
    await claimDraftService(transaction, serviceId, actorId, expectedVersion);
    const deleted = await transaction.catalogueOffering.deleteMany({
      where: { id: offeringId, serviceId },
    });
    if (deleted.count !== 1)
      throw new CatalogueConflictError("Offering not found.");
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.offering.deleted",
        targetType: "CatalogueOffering",
        targetId: offeringId,
        metadata: auditMetadata({ serviceId }),
      },
    });
    return { staged: false };
  });
}

export async function duplicateOffering(
  serviceId: string,
  offeringId: string,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await loadServiceAggregate(transaction, serviceId);
    const snapshot = editableSnapshot(service);
    const source = snapshot.offerings.find(({ id }) => id === offeringId);
    if (!source) throw new CatalogueConflictError("Offering not found.");
    const id = stagedId();
    const slug = nextDuplicateSlug(
      source.slug,
      snapshot.offerings.map((item) => item.slug),
    );
    const duplicate = {
      ...source,
      id,
      seededKey: null,
      slug,
      name: `${source.name} copy`,
      isActive: false,
      isFeatured: false,
      needsClientReview: true,
      facets: source.facets.map((facet) => ({ ...facet, id: stagedId() })),
      requirements: source.requirements.map((requirement) => ({
        ...requirement,
        id: stagedId(),
        seededKey: null,
      })),
    };
    if (service.publicationStatus === "PUBLISHED") {
      await persistServiceStage({
        transaction,
        service,
        snapshot: upsertStagedOffering(snapshot, duplicate),
        actorId,
        expectedVersion,
      });
    } else {
      await claimDraftService(transaction, serviceId, actorId, expectedVersion);
      await transaction.catalogueOffering.create({
        data: {
          ...duplicate,
          serviceId,
          gameModes: {
            create: duplicate.gameModes.map((gameMode) => ({ gameMode })),
          },
          facets: { create: duplicate.facets },
          requirements: { create: duplicate.requirements },
        },
      });
    }
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.offering.duplicated",
        targetType: "CatalogueOffering",
        targetId: id,
        metadata: auditMetadata({ serviceId, sourceId: offeringId }),
      },
    });
    return { id, staged: service.publicationStatus === "PUBLISHED" };
  });
}

export async function addOfferingRequirement(
  input: OfferingRequirementInput,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await loadServiceAggregate(transaction, input.serviceId);
    await assertRecommendationIsAcyclic(
      transaction,
      input.serviceId,
      input.recommendedServiceId,
      editableSnapshot(service),
    );
    const requirement = {
      id: stagedId(),
      title: input.title,
      description: input.description,
      type: input.type,
      isRequired: input.isRequired,
      displayOrder: input.displayOrder,
      verificationMode: input.verificationMode,
      customerGuidance: input.customerGuidance ?? null,
      metricKey: input.metricKey ?? null,
      comparisonOperator: input.comparisonOperator ?? null,
      requiredValue: input.requiredValue ?? null,
      recommendedServiceId: input.recommendedServiceId ?? null,
      seededKey: null,
    };
    if (service.publicationStatus === "PUBLISHED") {
      const snapshot = editableSnapshot(service);
      const offering = snapshot.offerings.find(
        ({ id }) => id === input.offeringId,
      );
      if (!offering) throw new CatalogueConflictError("Offering not found.");
      await persistServiceStage({
        transaction,
        service,
        snapshot: upsertStagedOffering(snapshot, {
          ...offering,
          requirements: [...offering.requirements, requirement],
        }),
        actorId,
        expectedVersion,
      });
    } else {
      await claimDraftService(
        transaction,
        input.serviceId,
        actorId,
        expectedVersion,
      );
      await transaction.catalogueOfferingRequirement.create({
        data: { ...requirement, offeringId: input.offeringId },
      });
    }
    await transaction.auditLog.create({
      data: {
        actorId,
        action:
          input.verificationMode === "AUTOMATIC"
            ? "catalogue.eligibility.automatic_rule_changed"
            : input.recommendedServiceId
              ? "catalogue.eligibility.prerequisite_changed"
              : "catalogue.offering.requirement_changed",
        targetType: "CatalogueOffering",
        targetId: input.offeringId,
        metadata: auditMetadata({
          serviceId: input.serviceId,
          requirementId: requirement.id,
          recommendedServiceId: input.recommendedServiceId ?? null,
        }),
      },
    });
    return {
      id: requirement.id,
      staged: service.publicationStatus === "PUBLISHED",
    };
  });
}

export async function deleteOfferingRequirement(
  serviceId: string,
  offeringId: string,
  requirementId: string,
  actorId: string,
  expectedVersion: number,
) {
  return prisma.$transaction(async (transaction) => {
    const service = await loadServiceAggregate(transaction, serviceId);
    if (service.publicationStatus === "PUBLISHED") {
      const snapshot = editableSnapshot(service);
      const offering = snapshot.offerings.find(({ id }) => id === offeringId);
      if (!offering?.requirements.some(({ id }) => id === requirementId)) {
        throw new CatalogueConflictError("Offering requirement not found.");
      }
      await persistServiceStage({
        transaction,
        service,
        snapshot: upsertStagedOffering(snapshot, {
          ...offering,
          requirements: offering.requirements.filter(
            ({ id }) => id !== requirementId,
          ),
        }),
        actorId,
        expectedVersion,
      });
    } else {
      await claimDraftService(transaction, serviceId, actorId, expectedVersion);
      const deleted = await transaction.catalogueOfferingRequirement.deleteMany(
        {
          where: { id: requirementId, offeringId },
        },
      );
      if (deleted.count !== 1)
        throw new CatalogueConflictError("Offering requirement not found.");
    }
    await transaction.auditLog.create({
      data: {
        actorId,
        action: "catalogue.offering.requirement_changed",
        targetType: "CatalogueOffering",
        targetId: offeringId,
        metadata: auditMetadata({ serviceId, requirementId, removed: true }),
      },
    });
    return { staged: service.publicationStatus === "PUBLISHED" };
  });
}
